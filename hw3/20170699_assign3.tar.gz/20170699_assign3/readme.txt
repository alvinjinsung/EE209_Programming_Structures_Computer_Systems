Name: 최진성
Student ID: 20170699
# of assignment: 3

-1 token use

-Array type: linearly saved so easy to find. Takes long time.
-Hash type: Takes less time. Complex structure so harder to find.
-Did not implement hash table expansion
