Name: 최진성
Student ID: 20170699
# of assignment: 2

Choice of implementation: used only the pointer notation for Part 1

Is it possible for StrCopy to call assert to verify that the destination memory area specified by the caller is large enough? 
No. The caller must check before using the function.
