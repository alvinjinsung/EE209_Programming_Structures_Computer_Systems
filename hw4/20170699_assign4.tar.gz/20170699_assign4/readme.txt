Name: 최진성
Student ID: 20170699
# of assignment: 4

-2 token use
